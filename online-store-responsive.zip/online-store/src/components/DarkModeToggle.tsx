export const DarkModeToggle = () => (
    <button className="dark-mode-toggle">
        🌙 Dark Mode
    </button>
);